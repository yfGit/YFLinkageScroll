//
//  BasicViewController.h
//  YFLinkageScrollView
//
//  Created by Wolf on 16/4/19.
//  Copyright © 2016年 许毓方. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BasicViewController : UIViewController

@property (nonatomic, strong) UILabel *label;

- (void)load;

@end
